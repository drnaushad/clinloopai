"""
ClinLoop AI — Neuro-Symbolic Dynamic Temporal Hypergraph Engine
for Unclosed Clinical Loop Detection & Patient Safety

Version: 1.0.0-competition
Author: ALAM MD NAUSHAD, Ajou University
"""

__version__ = "1.0.0"
__author__ = "ALAM MD NAUSHAD"
