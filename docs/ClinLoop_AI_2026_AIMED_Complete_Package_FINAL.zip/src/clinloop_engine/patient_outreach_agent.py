"""
patient_outreach_agent.py — Dual-Loop Patient Empathy & Omnichannel Outreach Agent

Bridges the health literacy gap by translating clinical obligations into empathetic,
plain-language patient messages in Korean & English, enabling 1-click mobile scheduling
and closing the loop directly with the human patient.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any
import json


@dataclass
class PatientOutreachProfile:
    patient_id: str
    patient_name: str
    preferred_language: str
    channel: str                     # KakaoTalk, SMS, VoiceAgent
    clinical_jargon: str
    plain_language_title: str
    plain_language_body: str
    action_button_label: str
    appointment_slot_suggested: str
    fhir_communication_request_id: str


OUTREACH_PROFILES: Dict[str, Dict[str, Any]] = {
    "SC-0062": {
        "patient_name": "김미영 (Kim Mi-young)",
        "preferred_language": "ko",
        "channel": "KakaoTalk 알림톡 / SMS",
        "clinical_jargon": "Cervical cytology HSIL (High-grade Squamous Intraepithelial Lesion)",
        "plain_language_title": "[아주대병원] 자궁경부 건강검진 정밀 추적진료 안내",
        "plain_language_body": "김미영님, 지난 3월 13일 시행하신 세포검사에서 전문의 상담 및 정밀검사(질확대경검사)가 필요한 변화가 발견되었습니다. 조기에 확인하시면 98% 이상 안전하게 치료 가능한 단계이오니, 30일 이내에 산부인과 외래 예약을 권고드립니다.",
        "action_button_label": "📅 1초 간편 예약하기 (3월 25일 오전 10:00 박교수)",
        "appointment_slot_suggested": "2026-03-25 10:00 KST (Gynecology Room 3, Prof. Park)",
        "fhir_communication_request_id": "COMM-REQ-0062-ASCCP"
    },
    "SC-0004": {
        "patient_name": "이정호 (Lee Jung-ho)",
        "preferred_language": "ko",
        "channel": "KakaoTalk 알림톡 / SMS",
        "clinical_jargon": "Incidental Pulmonary Nodule 7.8mm Right Upper Lobe (Fleischner Guideline)",
        "plain_language_title": "[아주대병원] 흉부 CT 추적검사 일정 사전 안내",
        "plain_language_body": "이정호님, 지난 6월 검사에서 폐 상엽에 7.8mm의 작은 결절(점)이 관찰되었습니다. 대다수의 결절은 양성이지만, 의학 안전 가이드라인에 따라 6개월 뒤 크기 변화 유무를 재확인하는 저선량 CT 검사가 필수적입니다. 권장 일정에 맞춰 검사를 예약해 드립니다.",
        "action_button_label": "📅 흉부 CT 추적검사 일정 확정하기 (11월 20일)",
        "appointment_slot_suggested": "2026-11-20 14:30 KST (Radiology CT Suite 2)",
        "fhir_communication_request_id": "COMM-REQ-0004-FLEISCHNER"
    },
    "SC-0098": {
        "patient_name": "박순자 (Park Soon-ja)",
        "preferred_language": "ko",
        "channel": "긴급 안심 음성전화 (Voice AI) + SMS",
        "clinical_jargon": "Warfarin dose increased to 7.5mg; Unmonitored INR Bleeding Risk",
        "plain_language_title": "[아주대병원] 와파린(항응고제) 복용량 변경에 따른 혈액응고(INR) 검사 안내",
        "plain_language_body": "박순자님, 최근 와파린 용량이 변경되어 약효가 안전하게 작용하는지 확인하기 위해 이번 주 내(7일 이내) 혈액검사(INR)가 꼭 필요합니다. 검사를 거르시면 멍이나 출혈 위험이 증가할 수 있습니다. 내일 오전 가까운 채혈실로 내원 부탁드립니다.",
        "action_button_label": "🩸 내일 채혈실 방문 확인 (원클릭 접수)",
        "appointment_slot_suggested": "2026-05-10 09:00 KST (Central Phlebotomy Lab)",
        "fhir_communication_request_id": "COMM-REQ-0098-WARFARIN"
    },
    "SC-0164": {
        "patient_name": "최은숙 (Choi Eun-sook)",
        "preferred_language": "ko",
        "channel": "KakaoTalk 알림톡",
        "clinical_jargon": "Incidental 10.8mm RLL Nodule; Follow-up Completed at Day 154",
        "plain_language_title": "[아주대병원] 흉부 추적 CT 검사 결과 안심 안내",
        "plain_language_body": "최은숙님, 권장 일정에 맞춰 시행하신 흉부 CT 검사 결과, 이전 결절이 커지지 않고 완전히 안정적인 양성 소견(비악성)으로 최종 확인되었습니다. 폐쇄루프 추적관리가 성공적으로 완료되었습니다.",
        "action_button_label": "✓ 검사 결과지 및 영상 확인하기",
        "appointment_slot_suggested": "Completed / Verified Stable",
        "fhir_communication_request_id": "COMM-REQ-0164-CLOSED"
    },
    "SC-0083": {
        "patient_name": "정우진 (Jung Woo-jin)",
        "preferred_language": "ko",
        "channel": "응급 자동 전화 (Direct Urgent Voice Callback)",
        "clinical_jargon": "Post-discharge Blood Culture Positive: Pseudomonas aeruginosa",
        "plain_language_title": "[아주대병원 응급의료센터] 퇴원 후 혈액배양검사 결과 긴급 방문 요청",
        "plain_language_body": "정우진님, 응급실 퇴원 후 진행 중이던 혈액배양검사에서 표적 항생제 치료가 필요한 세균(녹농균)이 확인되었습니다. 고열이나 패혈증으로 진행되기 전에 즉시 병원으로 재내원하셔서 정맥 항생제 치료를 받으셔야 합니다.",
        "action_button_label": "🚨 응급실 당직의 즉시 전화 연결",
        "appointment_slot_suggested": "IMMEDIATE RETURN TO ED (Bed Reserved)",
        "fhir_communication_request_id": "COMM-REQ-0083-CRITICAL"
    }
}


def get_patient_outreach(scenario_id: str) -> Dict[str, Any]:
    return OUTREACH_PROFILES.get(scenario_id, {})

if __name__ == "__main__":
    p = get_patient_outreach("SC-0062")
    print(f"Patient Outreach for {p['patient_name']} ({p['channel']}):")
    print(p["plain_language_title"])
    print(p["plain_language_body"])
    print(p["action_button_label"])
