"""
safety_clock.py — Safety Clock Mechanism

Implements the time-dependent risk escalation model.
As the deadline for a clinical obligation approaches and passes,
the risk score increases following a sigmoid curve.

Safety Clock States:
  GREEN  → Within safe window (< 50% of deadline elapsed)
  YELLOW → Approaching deadline (50-99% elapsed)
  RED    → Overdue (100-200% elapsed)
  BLACK  → Critically overdue (> 200% elapsed)
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Optional
import numpy as np


class ClockState(Enum):
    GREEN = "green"
    YELLOW = "yellow"
    RED = "red"
    BLACK = "black"


CLOCK_STATE_SCORES = {
    ClockState.GREEN: 0.1,
    ClockState.YELLOW: 0.4,
    ClockState.RED: 0.8,
    ClockState.BLACK: 1.0,
}


@dataclass
class SafetyClockReading:
    """A snapshot of the Safety Clock for one obligation."""
    obligation_id: str
    rule_id: str
    trigger_time: datetime
    deadline: datetime
    evaluation_time: datetime
    elapsed_days: float
    deadline_days: float
    fraction_elapsed: float
    time_risk: float
    clock_state: ClockState
    remaining_days: float
    urgency_label: str


class SafetyClock:
    """
    The Safety Clock assigns a continuous time-based risk score
    to each unclosed clinical obligation.
    
    The risk follows a sigmoid curve:
        time_risk(t) = 1 / (1 + exp(-k * (fraction_elapsed - threshold)))
    
    Where:
        - fraction_elapsed = elapsed_time / deadline
        - k = steepness parameter (higher = sharper transition)
        - threshold = fraction at which risk = 0.5 (default: 1.0 = at deadline)
    """

    def __init__(self, steepness: float = 8.0, threshold: float = 1.0):
        """
        Args:
            steepness: How sharply risk increases near the deadline.
                       Higher values = more cliff-like transition.
            threshold: The fraction_elapsed at which time_risk = 0.5.
                       Default 1.0 means risk reaches 0.5 exactly at deadline.
        """
        self.steepness = steepness
        self.threshold = threshold

    def compute_time_risk(self, fraction_elapsed: float) -> float:
        """
        Compute the time-based risk using a sigmoid function.
        
        Returns a value in [0, 1]:
          - Near 0 when well before deadline
          - 0.5 at the deadline
          - Near 1.0 when significantly past deadline
        """
        exponent = -self.steepness * (fraction_elapsed - self.threshold)
        return 1.0 / (1.0 + np.exp(exponent))

    def get_clock_state(self, fraction_elapsed: float) -> ClockState:
        """Determine the clock state based on fraction of deadline elapsed."""
        if fraction_elapsed < 0.5:
            return ClockState.GREEN
        elif fraction_elapsed < 1.0:
            return ClockState.YELLOW
        elif fraction_elapsed < 2.0:
            return ClockState.RED
        else:
            return ClockState.BLACK

    def evaluate(
        self,
        obligation_id: str,
        rule_id: str,
        trigger_time: datetime,
        deadline_days: float,
        evaluation_time: Optional[datetime] = None,
    ) -> SafetyClockReading:
        """
        Evaluate the Safety Clock for a specific obligation.
        
        Args:
            obligation_id: Unique identifier for the obligation
            rule_id: The clinical rule ID
            trigger_time: When the triggering event occurred
            deadline_days: Allowed time window in days
            evaluation_time: When we're evaluating (default: now)
        
        Returns:
            SafetyClockReading with all computed values
        """
        if evaluation_time is None:
            evaluation_time = datetime.now()

        deadline = trigger_time + timedelta(days=deadline_days)
        elapsed_days = (evaluation_time - trigger_time).total_seconds() / 86400
        fraction_elapsed = elapsed_days / deadline_days if deadline_days > 0 else float('inf')
        remaining_days = (deadline - evaluation_time).total_seconds() / 86400

        time_risk = self.compute_time_risk(fraction_elapsed)
        clock_state = self.get_clock_state(fraction_elapsed)

        # Generate human-readable urgency label
        if clock_state == ClockState.GREEN:
            urgency_label = f"Safe — {remaining_days:.0f} days remaining"
        elif clock_state == ClockState.YELLOW:
            urgency_label = f"Approaching deadline — {remaining_days:.0f} days left"
        elif clock_state == ClockState.RED:
            overdue = abs(remaining_days)
            urgency_label = f"OVERDUE by {overdue:.0f} days"
        else:
            overdue = abs(remaining_days)
            urgency_label = f"CRITICALLY OVERDUE by {overdue:.0f} days"

        return SafetyClockReading(
            obligation_id=obligation_id,
            rule_id=rule_id,
            trigger_time=trigger_time,
            deadline=deadline,
            evaluation_time=evaluation_time,
            elapsed_days=elapsed_days,
            deadline_days=deadline_days,
            fraction_elapsed=fraction_elapsed,
            time_risk=time_risk,
            clock_state=clock_state,
            remaining_days=remaining_days,
            urgency_label=urgency_label,
        )

    def compute_risk_curve(
        self, deadline_days: float, n_points: int = 100
    ) -> tuple:
        """
        Generate the full risk curve over time for plotting.
        
        Returns:
            (days_array, risk_array) for plotting
        """
        max_days = deadline_days * 2.5  # Plot up to 250% of deadline
        days = np.linspace(0, max_days, n_points)
        fractions = days / deadline_days
        risks = np.array([self.compute_time_risk(f) for f in fractions])
        return days, risks
